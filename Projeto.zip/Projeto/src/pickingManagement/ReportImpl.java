package pickingManagement;

import java.time.LocalDateTime;
import com.estg.pickingManagement.Report;

public class ReportImpl implements Report {


    private int usedVehicles;
    private int pickedContainers;
    private double totalDistance;
    private double totalDuration;
    private int nonPickedContainers;
    private int notUsedVehicles;
    private LocalDateTime date;


    public ReportImpl(int usedVehicles, int pickedContainers, double totalDistance,
                      double totalDuration, int nonPickedContainers,
                      int notUsedVehicles, LocalDateTime date) {
        this.usedVehicles = usedVehicles;
        this.pickedContainers = pickedContainers;
        this.totalDistance = totalDistance;
        this.totalDuration = totalDuration;
        this.nonPickedContainers = nonPickedContainers;
        this.notUsedVehicles = notUsedVehicles;
        this.date = date;
    }



    @Override
    public int getUsedVehicles() {
        return this.usedVehicles;
    }

    @Override
    public int getPickedContainers() {
        return this.pickedContainers;
    }

    @Override
    public double getTotalDistance() {
        return this.totalDistance;
    }

    @Override
    public double getTotalDuration() {
        return this.totalDuration;
    }

    @Override
    public int getNonPickedContainers() {
        return this.nonPickedContainers;
    }

    @Override
    public int getNotUsedVehicles() {
        return this.notUsedVehicles;
    }

    @Override
    public LocalDateTime getDate() {
        return this.date;
    }
}