package pickingManagement;

import com.estg.core.AidBox;
import com.estg.pickingManagement.Route;
import com.estg.pickingManagement.Vehicle;
import com.estg.pickingManagement.exceptions.RouteException;

public class RouteImpl implements Route {
    private AidBox[] aidBox;
    private int aidamount;
    private Route[] routes;
    private int numberRoutes;
    private Vehicle vehicle;


    public RouteImpl() {
        this.aidBox = new AidBox[50];
        this.aidamount = 0;
        this.routes = new Route[50];
        this.numberRoutes = 0;
        this.vehicle = vehicle;
    }

    @Override
    public void addAidBox(AidBox var1) throws RouteException {
        if (var1 == null) {
            throw new RouteException("Erorr");
        }
        if (this.aidBox.length == this.aidamount) {
            AidBox[] novo = new AidBox[aidBox.length * 2];
            for (int i = 0; i < this.aidamount; i++) {
                novo[i] = this.aidBox[i];
            }
            this.aidBox = novo;
        }
        this.aidBox[this.aidamount] = var1;
        this.aidamount++;
    }

    @Override
    public AidBox removeAidBox(AidBox var1) throws RouteException {
        if (var1 == null) {
            throw new RouteException("Error");
        }
        for (int i = 0; i < this.aidamount; i++) {
            if (this.aidBox[i].equals(var1)) {
                AidBox caixa = this.aidBox[i];
                for (int j = i; j < this.aidamount - 1; j++) {
                    this.aidBox[j] = this.aidBox[j + 1];
                }
                this.aidamount--;
                this.aidBox[this.aidamount] = null;
                return caixa;
            }
        }
        throw new RouteException("A caixa não foi encontrada nesta rota.");
    }

    @Override
    public boolean containsAidBox(AidBox var1) {
        if (var1 == null) {
            return false;
        }
        for (int i = 0; i < numberRoutes; i++) {
            if (routes[i].equals(var1)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void replaceAidBox(AidBox var1, AidBox var2) throws RouteException {
        if (var1 == null) {
            throw new RouteException("Error");
        }
        if (var2 == null) {
            throw new RouteException("eRRor");
        }
        for (int i = 0; i < aidamount; i++) {
            if (this.aidBox[i].equals(var1)) {
                aidBox[i] = var2;
            }
        }
    }

    @Override
   public AidBox[] getRoute() {
        AidBox[] rAid = new AidBox[aidamount];

        for (int i = 0; i < aidamount; i++) {
            rAid[i] = aidBox[i];
        }
        return  rAid;
    }
    @Override
    public Vehicle getVehicle() {
        return this.vehicle;
    }
    @Override
    public void insertAfter(AidBox var1, AidBox var2) throws RouteException {

    }
}



