package pickingManagement;

import com.estg.core.Institution;
import com.estg.pickingManagement.RouteValidator;
import com.estg.pickingManagement.Strategy;
import com.estg.pickingManagement.Route;

public class StrategyImpl implements Strategy {
    int ns;

    public StrategyImpl(int ns) {
        this.ns = ns;
    }
    @Override
    public Route[] generate(Institution var1, RouteValidator var2) {

    }
}
