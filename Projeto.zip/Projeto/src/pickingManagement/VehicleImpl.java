package pickingManagement;

import com.estg.core.ItemType;
import com.estg.pickingManagement.Vehicle;

public class VehicleImpl implements Vehicle {
    private ItemType supplyType;
    private double maxCapacity;

    public VehicleImpl(ItemType supplyType, double maxCapacity) {
        this.supplyType = supplyType;
        this.maxCapacity = maxCapacity;
    }

    @Override
    public ItemType getSupplyType() {
        return this.supplyType;
    }
    @Override
    public double getMaxCapacity() {
        return this.maxCapacity;
    }

}
