package core;

import com.estg.core.*;
import com.estg.core.exceptions.AidBoxException;
import com.estg.core.exceptions.ContainerException;
import com.estg.core.exceptions.MeasurementException;
import com.estg.core.exceptions.VehicleException;
import com.estg.pickingManagement.PickingMap;
import com.estg.pickingManagement.Vehicle;
import java.time.LocalDateTime;
import com.estg.core.exceptions.PickingMapException;
import com.estg.pickingManagement.PickingMap;

public class InstituitonImpl implements Institution {
   private String name;
   private int aidBoxesamount;
   private AidBox[] aBoxes;
   private Vehicle[] vehiclesI;
   private int vehiclesAmount;
   private boolean[] vehicleStatus;
    private PickingMap[] pickingMaps;
    private int pickingMapsAmount;


    public InstituitonImpl(String name, int aidBoxesamount, int vehiclesAmount) {
        this.name = name;
        this.aidBoxesamount = aidBoxesamount;
        this.aBoxes = new AidBox[50];
        this.vehiclesI = new Vehicle[50];
        this.vehiclesAmount = vehiclesAmount;
        this.vehicleStatus = new boolean[50];
        this.pickingMaps = new PickingMap[50];
        this.pickingMapsAmount = 0;
    }
    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public boolean addAidBox(AidBox var1) throws AidBoxException {
        if (var1 == null) {
            throw new AidBoxException("A caixa de suprimentos é inválida.");
        }
        if (this.aidBoxesamount == this.aBoxes.length) {
            AidBox[] novoArray = new AidBox[this.aBoxes.length * 2];
            for (int i = 0; i < this.aidBoxesamount; i++) {
                novoArray[i] = this.aBoxes[i];
            }
            this.aBoxes = novoArray;
        }
        this.aBoxes[this.aidBoxesamount] = var1;
        this.aidBoxesamount++;

        return true;
    }
    @Override
    public boolean addMeasurement(Measurement var1, Container var2) throws ContainerException, MeasurementException {
        if (var1 == null) {
            throw new MeasurementException("Invalid Measurement");
        }
        if (var2 == null) {
            throw new MeasurementException("Invalid Container");
        }

        return var2.addMeasurement(var1);

    }
    @Override
    public AidBox[] getAidBoxes() {
        AidBox[] activeAid = new AidBox[this.aidBoxesamount];

        for(int i = 0; i < this.aidBoxesamount; i++) {
            activeAid[i] = this.aBoxes[i];
        }
        return activeAid;
    }
    @Override
    public Container getContainer(AidBox var1, ItemType var2) throws ContainerException {
        if (var1 == null) {
            throw new ContainerException("Invalid aidbox");
        }
        Container containerItem = var1.getContainer(var2);

        if (containerItem == null) {
            throw new ContainerException("Não existe nenhum contentor para esse tipo de item nesta caixa.");
        }
        return containerItem;
    }
    @Override
    public Vehicle[] getVehicles() {
        Vehicle[] activeVehicles = new Vehicle[this.vehiclesAmount];

        for(int i = 0; i < this.vehiclesAmount; i++) {
            activeVehicles[i] = vehiclesI[i];
        }
        return activeVehicles;
    }
    @Override
    public boolean addVehicle(Vehicle var1) throws VehicleException {
        if (var1 == null) {
                throw new VehicleException("Invalid Vehicle");
    }
        if(this.vehiclesI.length == this.vehiclesAmount) {
            Vehicle[] array2 = new Vehicle[this.vehiclesI.length * 2];
            for (int i = 0; i < this.vehiclesAmount; i++) {
                array2[i] = this.vehiclesI[i];
            }
            this.vehiclesI = array2;
        }
        this.vehiclesI[this.vehiclesAmount] = var1;
        this.vehicleStatus[this.vehiclesAmount] = true;
        vehiclesAmount++;


    return  true;

}
@Override
public void disableVehicle(Vehicle var1) throws VehicleException {
        if (var1 == null) {
        throw new VehicleException("Invalid vehicle.");
    }
    for (int i = 0; i < this.vehiclesAmount; i++) {
        if (this.vehiclesI[i].equals(var1)) {
            this.vehicleStatus[i] = false;
            return;
        }
    }
    throw new VehicleException("Vehicle not found");
}

@Override
public void enableVehicle(Vehicle var1) throws VehicleException {
        if (var1 == null) {
            throw new VehicleException("Invalid vehicle");
            }
    for (int i = 0; i < this.vehiclesAmount; i++) {
        if (this.vehiclesI[i].equals(var1)) {
            this.vehicleStatus[i] = false;
            return;
        }
    }
    throw new VehicleException("Vehicle not found");
}

@Override
public boolean addPickingMap(PickingMap var1) throws PickingMapException {
    if (var1 == null) {
        throw new PickingMapException("O mapa de recolha é inválido.");
    }

    if (this.pickingMapsAmount == this.pickingMaps.length) {
        PickingMap[] novoArray = new PickingMap[this.pickingMaps.length * 2];
        for (int i = 0; i < this.pickingMapsAmount; i++) {
            novoArray[i] = this.pickingMaps[i];
        }
        this.pickingMaps = novoArray;
    }

    this.pickingMaps[this.pickingMapsAmount] = var1;
    this.pickingMapsAmount++;

    return true;
}
    @Override
    public PickingMap[] getPickingMaps() {
        PickingMap[] activeMaps = new PickingMap[this.pickingMapsAmount];
        for (int i = 0; i < this.pickingMapsAmount; i++) {
            activeMaps[i] = this.pickingMaps[i];
        }
        return activeMaps;
    }

    @Override
    public PickingMap getCurrentPickingMap() throws PickingMapException {
        if (this.pickingMapsAmount == 0) {
            throw new PickingMapException("Não existem mapas de recolha registados.");
        }

        return this.pickingMaps[this.pickingMapsAmount - 1];
    }

    @Override
    public PickingMap[] getPickingMaps(LocalDateTime var1, LocalDateTime var2) {
        int count = 0;

        for (int i = 0; i < this.pickingMapsAmount; i++) {
            LocalDateTime dataMapa = this.pickingMaps[i].getDate();
            if (!dataMapa.isBefore(var1) && !dataMapa.isAfter(var2)) {
                count++;
            }
        }

        PickingMap[] filteredMaps = new PickingMap[count];
        int index = 0;

        for (int i = 0; i < this.pickingMapsAmount; i++) {
            LocalDateTime dataMapa = this.pickingMaps[i].getDate();
            if (!dataMapa.isBefore(var1) && !dataMapa.isAfter(var2)) {
                filteredMaps[index] = this.pickingMaps[i];
                index++;
            }
        }

        return filteredMaps;
    }
}
