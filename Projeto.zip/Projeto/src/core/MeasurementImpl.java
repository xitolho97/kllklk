package core;

import com.estg.core.Measurement;
import java.time.LocalDateTime;

public class MeasurementImpl implements Measurement {
    private LocalDateTime date;
    private double value;

    public MeasurementImpl(double value, LocalDateTime date) {
        this.value = value;
        this.date = date;
    }

    @Override
    public LocalDateTime getDate() {
        return this.date;
    }
    @Override
    public double getValue() {
        return this.value;
    }


}
