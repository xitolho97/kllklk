package core;

import com.estg.core.AidBox;
import com.estg.core.Container;
import com.estg.core.GeographicCoordinates;
import com.estg.core.ItemType;
import com.estg.core.exceptions.AidBoxException;
import com.estg.core.exceptions.ContainerException;

import java.lang.classfile.instruction.ConstantInstruction;
import java.util.Arrays;


public class AidboxImpl implements AidBox {
    private Container[] containers;
    private int contadorContentores;
    private String code;
    private String zone;
    private String refLocal;
    private GeographicCoordinates Coordinates;

    public AidboxImpl(String code, String zone, String refLocal, GeographicCoordinates Coordinates) {
        this.code = code;
        this.zone = zone;
        this.refLocal = refLocal;
        this.Coordinates = Coordinates;
        this.containers = new Container[50];
        this.contadorContentores = 0;
    }

    @Override
    public String getCode() {
        return this.code;
    }
    @Override
    public String getZone() {
        return  this.zone;
    }

    @Override
    public String getRefLocal() {
        return this.refLocal;

    }
    @Override
    public double getDistance (AidBox uAidBox) throws AidBoxException {
        if(uAidBox == null) {
            throw new AidBoxException("The aidbox is invalid");
        }
        if(uAidBox.getCode().equals(this.code)) {
            return 0.0;
        }

        }

    @Override
    public GeographicCoordinates getCoordinates() {
        return this.Coordinates;
}
    @Override
   public boolean addContainer(Container var1) throws ContainerException {
        if(var1 == null) {
            throw new ContainerException("eRROR");
        }
        if(containers.length == this.contadorContentores) {
            Container[] novoA = new Container[this.containers.length * 2];
            for (int i = 0; i < this.contadorContentores; i++) {
                novoA[i] = this.containers[i];
            }
            this.containers = novoA;
        }
        this.containers[contadorContentores] = var1;
        contadorContentores++;
        return true;
    }
    @Override
    public  Container getContainer(ItemType var1) {
        for (int i = 0; i < contadorContentores; i++) {
            if (this.containers[i].equals(var1)) {
                return this.containers[i];
            }
        }
        return null;
    }
    @Override
    public Container[] getContainers() {
       Container[] ativos = new Container[contadorContentores];

       for (int i = 0; i < contadorContentores; i++) {
           ativos[i] = containers[i];
       }
       return ativos;
    }




}



