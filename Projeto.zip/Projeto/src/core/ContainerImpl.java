package core;

import com.estg.core.Container;
import com.estg.core.ItemType;
import com.estg.core.Measurement;
import com.estg.core.exceptions.MeasurementException;
import java.time.LocalDate;


public class ContainerImpl implements Container {
    private String code;
    private double maxCapacity;
    private ItemType type;
    private Measurement[] measurements;
    private int numberOfMeasurements;


    public ContainerImpl(String code, double maxCapacity, ItemType type) {
        this.code = code;
        this.maxCapacity = maxCapacity;
        this.measurements = new Measurement[10];
        this.type = type;
        this.numberOfMeasurements = 0;
    }

    @Override
    public String getCode() {

        return this.code;
    }

    @Override
    public double getCapacity() {
        return this.maxCapacity;
    }

    @Override
    public ItemType getType() {

        return this.type;
    }

    @Override
    public boolean addMeasurement(Measurement measurement) throws MeasurementException {
        if (measurement == null) {
            throw new MeasurementException("The measurement is invalid");
        }
        if (this.numberOfMeasurements == this.measurements.length) {
            Measurement[] newArray = new Measurement[this.measurements.length * 2];
            for (int i = 0; i < this.numberOfMeasurements; i++) {
                newArray[i] = this.measurements[i];
            }
            this.measurements = newArray;
        }
        this.measurements[this.numberOfMeasurements] = measurement;
        this.numberOfMeasurements++;

        return true;
    }

    @Override
    public Measurement[] getMeasurements() {
        int i;

        Measurement[] aMeasurements = new Measurement[this.numberOfMeasurements]; // so quero listar as measurements que existem logo crio nova variavel para alocar apenas na nova variavel

        for (i = 0; i < this.numberOfMeasurements; i++) {
            aMeasurements[i] = this.measurements[i];
        }
        return aMeasurements;
    }
    @Override
    public Measurement[] getMeasurements(LocalDate date) {
        int i;
        int matchCount = 0;

        if (date == null) {
            return new Measurement[0];
        }
        for (i = 0; i < this.numberOfMeasurements; i++) {
            if (this.measurements[i].getDate().toLocalDate().equals(date)) {
                matchCount++;

            }
        }
        Measurement[] mMeasurement = new Measurement[matchCount]; // criar o array de tamanho dos matches

        int currentPos = 0;
        for (i = 0; i < this.numberOfMeasurements; i++) {
            if (this.measurements[i].getDate().equals(date)) {
                mMeasurement[currentPos] = this.measurements[i];
                currentPos++;
            }
        }

        return mMeasurement;
    }

}
